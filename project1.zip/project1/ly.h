//
// Created by YOULIN-LIU on 2018-03-15.
//

#ifndef PROJECT1_LY_H
#define PROJECT1_LY_H


class ly {

};


#endif //PROJECT1_LY_H
