#ifndef SEAMCARVINGCOMP665156
#define SEAMCARVINGCOMP665156

#include <opencv2/opencv.hpp>


using namespace cv;
using namespace std;

bool seam_carving(Mat& in_image, int new_width, int new_height, Mat& out_image);

bool seam_carving_trivial(Mat& in_image, int new_width, int new_height, Mat& out_image);

bool show_horizontal_seam_color(Mat& in_image, Mat& out_image);

bool reduce_vertical_seam_color(cv::Mat& in_image, cv::Mat& out_image);

bool show_vertical_seam_color(cv::Mat& in_image, cv::Mat& out_image);


bool reduce_horizontal_seam_color(Mat& in_image, Mat& out_image);



#endif
