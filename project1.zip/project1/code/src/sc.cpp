
#include "sc.h"
#include <ctime>

using namespace cv;
using namespace std;




bool seam_carving(Mat& in_image, int new_width, int new_height, Mat& out_image){

    // some sanity checks
    // Check 1 -> new_width <= in_image.cols
    if(new_width>in_image.cols){
        cout<<"Invalid request!!! new_width has to be smaller than the current size of "<<in_image.cols<<"!"<<endl;
        return false;
    }
    if(new_height>in_image.rows){
        cout<<"Invalid request!!! new_height has to be smaller than the current size!"<<endl;
        return false;
    }

    if(new_width<=0){
        cout<<"Invalid request!!! new_width has to be positive!"<<endl;
        return false;

    }

    if(new_height<=0){
        cout<<"Invalid request!!! new_height has to be positive!"<<endl;
        return false;

    }


    return seam_carving_trivial(in_image, new_width, new_height, out_image);
}


// seam carves by removing trivial seamsyt3rrr
bool seam_carving_trivial(Mat& in_image, int new_width, int new_height, Mat& out_image){

    Mat iimage = in_image.clone();
    Mat oimage = in_image.clone();



    while(iimage.rows!=new_height || iimage.cols!=new_width){
        // horizontal seam if needed


        if(iimage.rows>new_height){


            reduce_horizontal_seam_color(iimage, oimage);
            iimage = oimage.clone();
        }




        if (iimage.cols > new_width) {


            reduce_vertical_seam_color(iimage, oimage);
            iimage = oimage.clone();
        }

    }





    out_image = oimage.clone();

    return true;
}




bool reduce_vertical_seam_color(cv::Mat& in_image, cv::Mat& out_image){

    Mat src, src_gray;
    int rows = in_image.rows;
    int cols = in_image.cols;
    int scale = 1;
    int delta = 0;
    int ddepth = CV_16S;
    src = in_image.clone();
    Mat nrj;
    GaussianBlur( src, src, Size(3,3), 0, 0, BORDER_DEFAULT );
    // cvtColor( src, src_gray, COLOR_RGB2GRAY );
    cvtColor( src, src_gray, CV_BGR2GRAY );

    Mat grad_x, grad_y;
    Mat abs_grad_x, abs_grad_y;

    // Scharr(src_gray, grad_x, ddepth, 1, 0, scale, delta, BORDER_DEFAULT);
    //  Scharr(src_gray, grad_y, ddepth, 0, 1, scale, delta, BORDER_DEFAULT);

    Sobel(src_gray, grad_x, ddepth, 1, 0, 1,scale, delta, BORDER_DEFAULT);
    Sobel(src_gray, grad_y, ddepth, 0, 1, 1,scale, delta, BORDER_DEFAULT);

    convertScaleAbs( grad_x, abs_grad_x );
    convertScaleAbs( grad_y, abs_grad_y );
    addWeighted( abs_grad_x, 0.5, abs_grad_y, 0.5, 0, nrj);


    int seamMat[rows][cols];

    for(int j=0;j<cols;++j){
        seamMat[0][j] = nrj.at<uchar>(0,j);
    }
    for(int i=1;i<rows;++i){
        for(int j=0;j<cols;++j){
            seamMat[i][j] = 0;
            if (j==0){
                //left
                int startPoint = nrj.at<uchar>(i,j);
                int endPoint1 = nrj.at<uchar>(i-1,j);
                int endPoint2 = nrj.at<uchar>(i-1,j+1);
                seamMat[i][j] = min ((abs(startPoint - endPoint1) + seamMat[i-1][j]),(abs(startPoint - endPoint2) + seamMat[i-1][j+1]));


            } else if (j==cols-1){
                //right
                int startPoint = nrj.at<uchar>(i,j);
                int endPoint1 = nrj.at<uchar>(i-1,j);
                int endPoint2 = nrj.at<uchar>(i-1,j-1);
                seamMat[i][j] = min ((abs(startPoint - endPoint1) + seamMat[i-1][j]),(abs(startPoint - endPoint2) + seamMat[i-1][j-1]));


            } else {
                int startPoint = nrj.at<uchar>(i,j);
                int endPoint1 = nrj.at<uchar>(i-1,j);
                int endPoint2 = nrj.at<uchar>(i-1,j+1);
                int endPoint3 = nrj.at<uchar>(i-1,j-1);
                seamMat[i][j] = min((abs(startPoint - endPoint3) + seamMat[i-1][j-1]), min ((abs(startPoint - endPoint1) + seamMat[i-1][j]),(abs(startPoint - endPoint2) + seamMat[i-1][j+1])));

            }
        }
    }
    int minCoord = 0;
    int mini = seamMat[rows-1][minCoord];

    for (int j = 0;j<cols;++j){
        if (mini >= seamMat[rows-1][j]) {
            mini = seamMat[rows-1][j];
            minCoord = j;
        }
    }

    out_image = Mat(rows, cols-1, CV_8UC3);
    //cols = cols-1;

    for (int i = rows-1; i>=0;--i){
        if (minCoord < cols-1){
            for(int j=0;j<minCoord;++j){
                Vec3b pixel = in_image.at<Vec3b>(i, j);
                out_image.at<Vec3b>(i,j) = pixel;
            }
            for(int j=minCoord+1;j<=cols;++j){
                Vec3b pixel = in_image.at<Vec3b>(i, j);
                out_image.at<Vec3b>(i,j-1) = pixel;
            }
        } else {
            for(int j=0;j<cols-1;++j){
                Vec3b pixel = in_image.at<Vec3b>(i, j);
                out_image.at<Vec3b>(i,j) = pixel;
            }
        }


        if (i<rows-1){
            if (minCoord ==0){
                mini = min(seamMat[i-1][minCoord], seamMat[i-1][minCoord+1]);
                if (mini == seamMat[i-1][minCoord+1]) minCoord = minCoord+1;
            } else if (minCoord ==cols-1){
                mini = min(seamMat[i-1][minCoord], seamMat[i-1][minCoord-1]);
                if (mini == seamMat[i-1][minCoord-1]) minCoord = minCoord-1;
            } else {
                mini = min(seamMat[i-1][minCoord], min(seamMat[i-1][minCoord+1], seamMat[i-1][minCoord-1]));
                if (mini == seamMat[i-1][minCoord-1]) minCoord = minCoord-1;
                if (mini == seamMat[i-1][minCoord+1]) minCoord = minCoord+1;
            }
        }
    }
    return true;
}


bool reduce_horizontal_seam_color(Mat& in_image, Mat& out_image){
    //cout<<"horizontal ";
    Mat src, src_gray;
    int rows = in_image.rows;
    int cols = in_image.cols;
    int scale = 1;
    int delta = 0;
    int ddepth = CV_16S;
    src = in_image.clone();
    Mat nrj;
    GaussianBlur( src, src, Size(3,3), 0, 0, BORDER_DEFAULT );
    cvtColor( src, src_gray, CV_BGR2GRAY );

    Mat grad_x, grad_y;
    Mat abs_grad_x, abs_grad_y;

    // Scharr(src_gray, grad_x, ddepth, 1, 0, scale, delta, BORDER_DEFAULT);
    // Scharr(src_gray, grad_y, ddepth, 0, 1, scale, delta, BORDER_DEFAULT);
    Sobel(src_gray, grad_x, ddepth, 1, 0, 1,scale, delta, BORDER_DEFAULT);
    Sobel(src_gray, grad_y, ddepth, 0, 1, 1,scale, delta, BORDER_DEFAULT);
    convertScaleAbs( grad_x, abs_grad_x );
    convertScaleAbs( grad_y, abs_grad_y );
    addWeighted( abs_grad_x, 0.5, abs_grad_y, 0.5, 0, nrj);


    int seamMat[rows][cols];

    for(int i=0;i<rows;++i){
        seamMat[i][0] = nrj.at<uchar>(i,0);;
    }

    for(int j=1;j<cols;++j){
        for(int i=0;i<rows;++i){
            seamMat[i][j] = 0;
            if (i==0){
                //top case
                int startPoint = nrj.at<uchar>(i,j);
                int endPoint1 = nrj.at<uchar>(i,j-1);
                int endPoint2 = nrj.at<uchar>(i+1,j-1);
                seamMat[i][j] = min ((abs(startPoint - endPoint1) + seamMat[i][j-1]),(abs(startPoint - endPoint2) + seamMat[i+1][j-1]));
                // seamMat[i][j] = min (seamMat[i][j-1], seamMat[i+1][j-1]);
            } else if (i==rows-1){
                //bot case
                int startPoint = nrj.at<uchar>(i,j);
                int endPoint1 = nrj.at<uchar>(i,j-1);
                int endPoint2 = nrj.at<uchar>(i-1,j-1);
                seamMat[i][j] = min ((abs(startPoint - endPoint1) + seamMat[i][j-1]),(abs(startPoint - endPoint2) + seamMat[i-1][j-1]));
                // seamMat[i][j] = min (seamMat[i][j-1],seamMat[i-1][j-1]);
            } else {
                int startPoint = nrj.at<uchar>(i,j);
                int endPoint1 = nrj.at<uchar>(i,j-1);
                int endPoint2 = nrj.at<uchar>(i+1,j-1);
                int endPoint3 = nrj.at<uchar>(i-1,j-1);
                // seamMat[i][j] = min(seamMat[i-1][j-1],min (seamMat[i][j-1],seamMat[i+1][j-1]));
                seamMat[i][j] = min((abs(startPoint - endPoint3) + seamMat[i-1][j-1]), min ((abs(startPoint - endPoint1) + seamMat[i][j-1]),(abs(startPoint - endPoint2) + seamMat[i+1][j-1])));
            }
            // seamMat[i][j] += nrj.at<uchar>(i,j);
        }
    }

    int minCoord = 0;
    // int minCoord = 2147483647;
    int mini = seamMat[minCoord][cols];
    // int mini = -1;
    for (int i = 0;i<rows;++i){
        if (mini > seamMat[i][cols-1]) {
            mini = seamMat[i][cols-1];
            minCoord = i;
        }
    }


    out_image = Mat(rows-1, cols, CV_8UC3);
    //rows = rows -1;
    for (int j = cols-1; j>=0;--j){

        if (minCoord < rows-1){
            for(int i=0;i<=minCoord;++i){
                Vec3b pixel = in_image.at<Vec3b>(i, j);
                out_image.at<Vec3b>(i,j) = pixel;
            }
            for(int i=minCoord+1;i<rows;++i){
                Vec3b pixel = in_image.at<Vec3b>(i, j);
                out_image.at<Vec3b>(i-1,j) = pixel;
            }
        } else {
            for(int i=0;i<rows-1;++i){
                Vec3b pixel = in_image.at<Vec3b>(i, j);
                out_image.at<Vec3b>(i,j) = pixel;
            }
        }


        // cout<<rows<<" "<<cols<<" step-"<<j<<" minCoord-"<<minCoord<<endl;
        if (j<cols-1){
            if (minCoord ==0){
                //cout<<seamMat[minCoord][j-1]<<"__"<<seamMat[minCoord+1][j-1]<<endl;
                mini = min(seamMat[minCoord][j-1], seamMat[minCoord+1][j-1]);
                if (mini == seamMat[minCoord+1][j-1]) minCoord = minCoord+1;
            } else if (minCoord ==rows-1){
                // cout<<seamMat[minCoord][j-1]<<"__"<<seamMat[minCoord-1][j-1]<<endl;
                mini = min(seamMat[minCoord][j-1], seamMat[minCoord-1][j-1]);
                if (mini == seamMat[minCoord-1][j-1]) minCoord = minCoord-1;
            } else {
                // cout<<seamMat[minCoord][j-1]<<"__"<<seamMat[minCoord-1][j-1]<<"__"<<seamMat[minCoord+1][j-1]<<endl;
                mini = min(seamMat[minCoord][j-1], min(seamMat[minCoord+1][j-1], seamMat[minCoord-1][j-1]));
                if (mini == seamMat[minCoord-1][j-1]) minCoord = minCoord-1;
                if (mini == seamMat[minCoord+1][j-1]) minCoord = minCoord+1;
            }
        }
    }

    return true;
}




